package com.example.productservices.services;

public interface ProductService {
}
