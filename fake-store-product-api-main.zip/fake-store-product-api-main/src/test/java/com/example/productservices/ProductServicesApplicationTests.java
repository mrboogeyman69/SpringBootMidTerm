package com.example.productservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServicesApplicationTests {

    @Test
    void contextLoads() {
    }

}
